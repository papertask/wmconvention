<div id="icl_setup_wizard_wrap" class="margin-top  wpml-section-wizard-steps">
    <div class="wpml-section-wizard-steps-inner wpml-section">
        <div id="icl_setup_wizard" class="wpml-section-content clearfix">
            <div class="icl_setup_wizard_step"><?php _e('1. Content language', 'sitepress')?></div>
            <div class="icl_setup_wizard_step"><?php _e('2. Translation languages', 'sitepress')?></div>
            <div class="icl_setup_wizard_step"><?php _e('3. Language switcher', 'sitepress')?></div>
            <div class="icl_setup_wizard_step"><?php _e('4. Registration', 'sitepress')?></div>
        </div>
        <div id="icl_setup_wizard_progress">
            <div id="icl_setup_wizard_progress_bar" style="width:<?php echo $sw_width ?>%">&nbsp;</div>
        </div>
    </div>
</div>
